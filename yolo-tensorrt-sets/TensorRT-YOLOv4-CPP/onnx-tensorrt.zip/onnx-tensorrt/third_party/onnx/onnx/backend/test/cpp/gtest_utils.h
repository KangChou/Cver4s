#include "gtest/gtest.h"
#include "onnx/backend/test/cpp/driver/test_driver.h"
namespace ONNX_NAMESPACE {
namespace testing {
std::vector<ONNX_NAMESPACE::testing::ResolvedTestCase>& GetTestCases();
}
} // namespace ONNX_NAMESPACE
